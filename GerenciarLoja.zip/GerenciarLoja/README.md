# ConexaoBD
Projeto Maven com conexao ao banco JavaDB
